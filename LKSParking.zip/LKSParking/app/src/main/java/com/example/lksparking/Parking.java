package com.example.lksparking;


import java.util.ArrayList;

public class Parking {
    private ArrayList<Coche> aparcamientos;

    public Coche getCoche(int i){
        return aparcamientos.get(i);
    }


}
