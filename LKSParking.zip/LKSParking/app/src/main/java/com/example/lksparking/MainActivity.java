package com.example.lksparking;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity {

    /*botones para navegar por las 2 actividades, para mirar que aparcamientos tienes o cancelarlos
    y la para poder reservar*/
    private MaterialButton btn_mirarAparcamientos, btn_reservar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_mirarAparcamientos = findViewById(R.id.btn_mirarAparcamientos);
        btn_reservar = findViewById(R.id.btn_reservar);

        btn_mirarAparcamientos.setOnClickListener(this::mirarAparcamientos);
        btn_reservar.setOnClickListener(this::reservar);


    }
    public void mirarAparcamientos(View v) {

    }
    public void reservar(View v) {

    }
}