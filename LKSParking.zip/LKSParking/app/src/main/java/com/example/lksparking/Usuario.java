package com.example.lksparking;

public class Usuario {
}
